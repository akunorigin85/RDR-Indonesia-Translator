package com.example.rdrtranslator

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "RDR Indonesia Translator"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "Aplikasi dasar berhasil dipasang. Fitur tangkap layar, OCR, dan terjemahan otomatis belum tersedia."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val button = Button(this).apply {
            text = "Tentang aplikasi"
            setOnClickListener {
                info.text = "Ini adalah prototipe dasar. Integrasi OCR, penerjemahan, dan overlay perlu dikembangkan serta diuji pada perangkat dan game."
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(button)
        setContentView(layout)
    }
}
