# RDR Indonesia Translator — Android starter project

This is a starter Android project targeting Android 13 compatibility.

## Current functionality
This version is only a basic app shell. It does not yet capture the game screen, recognize subtitles (OCR), translate text, or display a floating overlay. Those features require separate implementation, permission handling, and testing with the target game.

## Build
Use the GitHub Actions workflow described in the setup instructions to build a debug APK.
