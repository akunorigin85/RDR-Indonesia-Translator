# RDR Indonesia Translator — Android starter project

This repository is a starter Android application and GitHub Actions APK build workflow.

## Important limitation
This starter currently builds a basic Android app only. It does **not** yet capture the game screen, recognize subtitles, or translate them automatically. Those features require additional MediaProjection, OCR, translation integration, permission handling, and device/game testing.

## Build
Push the project to GitHub. Open **Actions** → **Build Android APK** → **Run workflow**. Download the artifact named `RDR-Indonesia-Translator-APK`.
