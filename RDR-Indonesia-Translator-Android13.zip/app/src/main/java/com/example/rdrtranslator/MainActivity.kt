package com.example.rdrtranslator

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "RDR Indonesia Translator"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "Versi prototipe. Fitur tangkap layar, OCR, dan terjemahan otomatis belum diaktifkan."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val button = Button(this).apply {
            text = "Tentang aplikasi"
            setOnClickListener {
                info.text = "Proyek dasar berhasil dipasang. Integrasi OCR dan penerjemah perlu tahap pengembangan dan pengujian berikutnya."
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(button)
        setContentView(layout)
    }
}
